const express = require('express');
const mysql = require('mysql');
const path = require('path');
const multer = require('multer');
const ExcelJS = require('exceljs');
const app = express();
const cors = require('cors');

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

const db = mysql.createConnection({
  host: 'awase1penatd01',
  user: 'remote2',
  password: 'rlsys2@jbl',
  database: 'rlsys'
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to database:', err);
    return;
  }
  console.log('Connected to database');
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

app.post('/upload', upload.single('file'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }

  const filePath = path.join(__dirname, req.file.path);
  const workbook = new ExcelJS.Workbook();
  try {
    await workbook.xlsx.readFile(filePath);
    console.log('Workbook loaded successfully');
  } catch (error) {
    console.error('Error reading Excel file:', error);
    return res.status(500).json({ message: 'Error reading Excel file' });
  }

  // Log all worksheet names
  workbook.eachSheet((worksheet, sheetId) => {
    console.log(`Worksheet ID: ${sheetId}, Name: ${worksheet.name}`);
  });

  // Access the worksheet by name or index
  const worksheet = workbook.getWorksheet('Standard Template'); // Change to the correct worksheet name
  if (!worksheet) {
    console.error('Worksheet not found');
    return res.status(500).json({ message: 'Worksheet not found' });
  }

  // Validate columns
  const expectedColumns = [
    'PROCESS TYPE', 'SITE', 'WORKCELL', 'CUSTOMER', 'PROBLEM/FAILURE MODE',
    'POTENTIAL CAUSE /ROOT CAUSE', 'PREVENTION CONTROL', 'DETECTION CONTROL', 'LAST MODIFIED DATE'
  ];

  const actualColumns = worksheet.getRow(1).values.slice(1); // Get header row values
  const isValid = expectedColumns.every((col, index) => col === actualColumns[index]);

  if (!isValid) {
    console.error('Invalid worksheet columns');
    return res.status(400).json({ message: 'Invalid worksheet columns' });
  }

  const data = [];
  worksheet.eachRow((row, rowNumber) => {
    if (rowNumber > 1) { // Skip header row
      data.push({
        process_type: cleanString(row.getCell(1).value),
        site: cleanString(row.getCell(2).value),
        workcell: cleanString(row.getCell(3).value),
        customer: cleanString(row.getCell(4).value),
        problem_failure_mode: cleanString(row.getCell(5).value),
        potential_cause_root_cause: cleanString(row.getCell(6).value),
        prevention_control: truncateString(cleanString(row.getCell(7).value), 255), // Truncate to 255 characters
        detection_control: truncateString(cleanString(row.getCell(8).value), 255), // Truncate to 255 characters
        last_modified_date: row.getCell(9).value
      });
    }
  });

  console.log('Extracted data:', data); // Log extracted data

  const query = `
    INSERT INTO exceldata (process_type, site, workcell, customer, problem_failure_mode, potential_cause_root_cause, prevention_control, detection_control, last_modified_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.beginTransaction((err) => {
    if (err) {
      console.error('Error starting transaction:', err);
      return res.status(500).json({ message: 'Error starting transaction' });
    }

    let hasError = false;

    data.forEach((row, index) => {
      db.query(query, [
        row.process_type,
        row.site,
        row.workcell,
        row.customer,
        row.problem_failure_mode,
        row.potential_cause_root_cause,
        row.prevention_control,
        row.detection_control,
        row.last_modified_date
      ], (err) => {
        if (err) {
          hasError = true;
          console.error(`Error inserting data at row ${index + 1}:`, err);
          return db.rollback(() => {
            res.status(500).json({ message: 'Error inserting data' });
          });
        }
      });
    });

    if (!hasError) {
      db.commit((err) => {
        if (err) {
          return db.rollback(() => {
            console.error('Error committing transaction:', err);
            res.status(500).json({ message: 'Error committing transaction' });
          });
        }
        res.status(200).json({ message: 'File uploaded successfully' });
      });
    }
  });
});

app.get('/api/data', (req, res) => {
  db.query('SELECT * FROM exceldata', (err, results) => {
    if (err) {
      console.error('Error fetching data:', err);
      return res.status(500).json({ message: 'Error fetching data' });
    }
    res.json(results);
  });
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});

function cleanString(str) {
  if (typeof str === 'string') {
    return str.replace(/[\u200B-\u200D\uFEFF]/g, ''); // Remove zero-width characters
  }
  return str;
}

function truncateString(str, maxLength) {
  if (typeof str === 'string' && str.length > maxLength) {
    return str.substring(0, maxLength);
  }
  return str;
}